require "/scripts/behavior.lua"
require "/scripts/pathing.lua"
require "/scripts/util.lua"
require "/scripts/vec2.lua"
require "/scripts/quest/participant.lua"
require "/scripts/relationships.lua"
require "/scripts/actions/dialog.lua"
require "/scripts/actions/movement.lua"
require "/scripts/drops.lua"
require "/scripts/statusText.lua"
require "/scripts/tenant.lua"
require "/scripts/companions/recruitable.lua"

-- Engine callback - called on initialization of entity
orVillagerPoliceInit = init
function init()
  if not orVillagerPoliceInit then return end
  orVillagerPoliceInit()
  script.setUpdateDelta(5)
  
  math.randomseed(util.seedTime())
  self.calledPolice = false --This is to keep track of wether or not the NPC has called the Space Police
  self.canCallPolice = math.random(1,3) == 1 --Chance to call Police, not every npc will have the ability to call, because most villages have more than 1, it helps to stop multiple calls of police.
  self.healthThreshold = math.random(1,75)/100 --Health lower than this means it can call the police
end


-- Engine callback - called on each update
-- Update frequencey is dependent on update delta
orVillagerPoliceUpdate = update
function update(dt)
local species = {"apex","avian","floran","glitch","human","hylotl","novakid"}
  if not orVillagerPoliceUpdate then return end
  orVillagerPoliceUpdate(dt)
  local etype = world.entityTypeName(entity.id())
  if not self.typeRead then 
	 local etype = world.entityTypeName(entity.id())
	 self.npcTypeCanCallPolice = (string.find(etype,"villager") or string.find(etype,"merchant"))
	 self.typeRead = true
  end
  if self.npcTypeCanCallPolice then
	  if not self.calledPolice and self.canCallPolice and status.resourcePercentage("health") < self.healthThreshold then
		local level = world.threatLevel()-2
		level = (level <= 0 and 1) or level
		if math.random(1,4) == 1 then --1 in 4 chance of spawning Coptop team.
			world.spawnNpc({mcontroller.xPosition() + 2, mcontroller.yPosition()}, species[math.random(#species)], "riotpeacekeeper", level) 
			world.spawnNpc({mcontroller.xPosition() - 2, mcontroller.yPosition()}, species[math.random(#species)], "riotpeacekeeper", level)
		else --Spawn normal police
			world.spawnNpc({mcontroller.xPosition() + 2, mcontroller.yPosition()}, species[math.random(#species)], "r-peacekeeper", level)
			world.spawnNpc({mcontroller.xPosition() - 2, mcontroller.yPosition()}, species[math.random(#species)], "r-peacekeeper", level)
		end
		self.calledPolice = true --NPC has called for Space Police, so no more help will come for that specific NPC
	  end
  end
end
