function init()
   effect.addStatModifierGroup({{stat = "grit", amount = 0.5}})

   script.setUpdateDelta(0)
end

function update(dt)

end

function uninit()

end
